import { useState, useEffect } from "react";
import { Search, SlidersHorizontal, Loader2 } from "lucide-react";
import api from "../utils/api";
import MedicineCard from "../components/user/MedicineCard";

export default function HomePage() {
  const [medicines, setMedicines] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  useEffect(() => {
    fetchMedicines();
  }, [search, category]);

  async function fetchMedicines() {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (category) params.category = category;
      const { data } = await api.get("/medicines/", { params });
      setMedicines(data.medicines);
      setCategories(data.categories);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Hero */}
      <div className="bg-gradient-to-br from-brand-600 to-brand-800 rounded-2xl p-6 mb-8 text-white">
        <h1 className="text-2xl sm:text-3xl font-bold mb-1">Your Health, Delivered</h1>
        <p className="text-brand-100 text-sm sm:text-base">
          Order medicines online — fast, safe & cash on delivery.
        </p>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="input pl-10"
            placeholder="Search medicines or brands..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="relative">
          <SlidersHorizontal size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <select
            className="input pl-10 pr-8 appearance-none cursor-pointer sm:w-48"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Results count */}
      {!loading && (
        <p className="text-sm text-gray-500 mb-4">
          {medicines.length} {medicines.length === 1 ? "medicine" : "medicines"} found
          {category ? ` in ${category}` : ""}
          {search ? ` for "${search}"` : ""}
        </p>
      )}

      {/* Grid */}
      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 size={32} className="animate-spin text-brand-500" />
        </div>
      ) : medicines.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-4xl mb-3">💊</p>
          <p className="text-gray-500 font-medium">No medicines found</p>
          <p className="text-gray-400 text-sm mt-1">Try a different search or category</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {medicines.map((med) => (
            <MedicineCard key={med.id} med={med} />
          ))}
        </div>
      )}
    </div>
  );
}
