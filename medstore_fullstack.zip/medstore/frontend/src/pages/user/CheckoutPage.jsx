import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { Loader2, ChevronRight } from "lucide-react";
import api from "../../utils/api";
import { useCart } from "../../context/CartContext";

const INDIAN_STATES = [
  "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat",
  "Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
  "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan",
  "Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal",
  "Andaman & Nicobar Islands","Chandigarh","Dadra & Nagar Haveli","Daman & Diu",
  "Delhi","Jammu & Kashmir","Ladakh","Lakshadweep","Puducherry",
];

const FIELD = ({ label, required, children }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-1.5">
      {label}{required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
    {children}
  </div>
);

export default function CheckoutPage() {
  const { cart, totalAmount, clearCart } = useCart();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    full_name: "", mobile: "", email: "", address: "",
    city: "", state: "", pin_code: "", landmark: "", order_notes: "",
  });

  if (cart.length === 0) {
    navigate("/");
    return null;
  }

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        ...form,
        items: cart.map((i) => ({ medicine_id: i.id, quantity: i.qty })),
      };
      const { data } = await api.post("/orders/", payload);
      clearCart();
      navigate("/order-success", { state: { order: data } });
    } catch (err) {
      const msg = err.response?.data?.errors?.join(" · ") || err.response?.data?.error || "Failed to place order.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Checkout</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-5">
          {/* Contact */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-4">Contact Details</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <FIELD label="Full Name" required>
                <input className="input" placeholder="John Doe" value={form.full_name}
                  onChange={set("full_name")} required />
              </FIELD>
              <FIELD label="Mobile Number" required>
                <input className="input" type="tel" placeholder="9876543210" value={form.mobile}
                  onChange={set("mobile")} required pattern="[0-9]{10,13}" />
              </FIELD>
              <FIELD label="Email Address">
                <input className="input" type="email" placeholder="Optional" value={form.email}
                  onChange={set("email")} />
              </FIELD>
            </div>
          </div>

          {/* Address */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-4">Delivery Address</h2>
            <div className="space-y-4">
              <FIELD label="Complete Address" required>
                <textarea className="input resize-none" rows={3}
                  placeholder="House/Flat No., Building, Street, Area..."
                  value={form.address} onChange={set("address")} required />
              </FIELD>
              <div className="grid sm:grid-cols-2 gap-4">
                <FIELD label="City" required>
                  <input className="input" placeholder="Rajkot" value={form.city}
                    onChange={set("city")} required />
                </FIELD>
                <FIELD label="State" required>
                  <select className="input" value={form.state} onChange={set("state")} required>
                    <option value="">Select State</option>
                    {INDIAN_STATES.map((s) => <option key={s}>{s}</option>)}
                  </select>
                </FIELD>
                <FIELD label="PIN Code" required>
                  <input className="input" placeholder="360001" value={form.pin_code}
                    onChange={set("pin_code")} required pattern="\d{6}" maxLength={6} />
                </FIELD>
                <FIELD label="Landmark">
                  <input className="input" placeholder="Near school, temple..." value={form.landmark}
                    onChange={set("landmark")} />
                </FIELD>
              </div>
            </div>
          </div>

          {/* Payment + Notes */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-4">Payment & Notes</h2>
            <div className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-xl mb-4">
              <span className="text-2xl">💵</span>
              <div>
                <p className="font-medium text-green-800 text-sm">Cash on Delivery</p>
                <p className="text-xs text-green-600">Pay when your order arrives.</p>
              </div>
              <div className="ml-auto w-5 h-5 rounded-full bg-green-600 flex items-center justify-center">
                <span className="text-white text-xs">✓</span>
              </div>
            </div>
            <FIELD label="Order Notes">
              <textarea className="input resize-none" rows={2} placeholder="Special instructions (optional)..."
                value={form.order_notes} onChange={set("order_notes")} />
            </FIELD>
          </div>

          <button type="submit" disabled={submitting}
            className="btn-primary w-full flex items-center justify-center gap-2 text-base py-3">
            {submitting ? <Loader2 size={18} className="animate-spin" /> : <ChevronRight size={18} />}
            {submitting ? "Placing Order..." : "Place Order"}
          </button>
        </form>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="card sticky top-20">
            <h2 className="font-semibold text-gray-900 mb-4">Order Summary</h2>
            <div className="space-y-3 mb-4 max-h-72 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between gap-2 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium text-gray-800 truncate">{item.name}</p>
                    <p className="text-gray-400 text-xs">x{item.qty}</p>
                  </div>
                  <p className="font-semibold text-gray-900 shrink-0">
                    ₹{(item.price * item.qty).toFixed(2)}
                  </p>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-4 space-y-2 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>Delivery</span><span className="text-green-600 font-medium">FREE</span>
              </div>
              <div className="flex justify-between font-bold text-gray-900 text-base pt-1">
                <span>Total</span><span>₹{totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
