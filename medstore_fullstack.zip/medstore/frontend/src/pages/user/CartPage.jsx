import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCart } from "../../context/CartContext";

export default function CartPage() {
  const { cart, setQty, removeFromCart, totalAmount, totalItems } = useCart();

  if (cart.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">🛒</div>
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Your cart is empty</h2>
        <p className="text-gray-500 mb-6 text-sm">Add medicines from our store to get started.</p>
        <Link to="/" className="btn-primary inline-flex">Browse Medicines</Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">
        Your Cart <span className="text-brand-600">({totalItems})</span>
      </h1>

      <div className="space-y-3 mb-6">
        {cart.map((item) => (
          <div key={item.id} className="card flex items-center gap-4">
            {/* Medicine icon */}
            <div className="w-12 h-12 bg-brand-50 rounded-xl flex items-center justify-center shrink-0 text-xl">
              💊
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="font-medium text-gray-900 text-sm truncate">{item.name}</p>
              <p className="text-xs text-gray-500">{item.brand} · {item.unit}</p>
              <p className="text-sm font-semibold text-brand-600 mt-1">
                ₹{(item.price * item.qty).toFixed(2)}
                <span className="text-gray-400 font-normal ml-1">(₹{item.price} each)</span>
              </p>
            </div>

            {/* Qty controls */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => item.qty === 1 ? removeFromCart(item.id) : setQty(item.id, item.qty - 1)}
                className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center
                           justify-center transition-colors active:scale-95"
              >
                {item.qty === 1 ? <Trash2 size={14} className="text-red-500" /> : <Minus size={14} />}
              </button>
              <span className="w-6 text-center font-semibold text-sm">{item.qty}</span>
              <button
                onClick={() => setQty(item.id, item.qty + 1)}
                className="w-8 h-8 rounded-lg bg-brand-600 hover:bg-brand-700 text-white flex
                           items-center justify-center transition-colors active:scale-95"
              >
                <Plus size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="card bg-gray-50 border-gray-200 mb-4">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Subtotal ({totalItems} items)</span>
          <span>₹{totalAmount.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-600 mb-3">
          <span>Delivery</span>
          <span className="text-green-600 font-medium">FREE</span>
        </div>
        <div className="border-t border-gray-200 pt-3 flex justify-between font-bold text-gray-900 text-lg">
          <span>Total</span>
          <span>₹{totalAmount.toFixed(2)}</span>
        </div>
      </div>

      <Link to="/checkout" className="btn-primary w-full flex items-center justify-center gap-2 text-base py-3">
        <ShoppingBag size={18} />
        Proceed to Checkout
      </Link>

      <Link to="/" className="block text-center text-sm text-brand-600 hover:underline mt-4">
        ← Continue Shopping
      </Link>
    </div>
  );
}
