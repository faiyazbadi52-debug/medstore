import { useState } from "react";
import { Search, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "react-hot-toast";
import api from "../../utils/api";
import StatusBadge from "../../components/shared/StatusBadge";
import { format } from "date-fns";

export default function HistoryPage() {
  const [mobile, setMobile] = useState("");
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [expanded, setExpanded] = useState({});

  async function fetchHistory() {
    if (!mobile.trim()) { toast.error("Enter your mobile number"); return; }
    setLoading(true);
    setOrders([]);
    setSearched(false);
    try {
      const { data } = await api.get("/orders/history", { params: { mobile: mobile.trim() } });
      setOrders(data.orders);
      setSearched(true);
    } catch (err) {
      toast.error(err.response?.data?.error || "Failed to fetch orders.");
    } finally {
      setLoading(false);
    }
  }

  const toggle = (id) => setExpanded((e) => ({ ...e, [id]: !e[id] }));

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">My Orders</h1>

      <div className="flex gap-2 mb-8">
        <input
          className="input flex-1"
          type="tel"
          placeholder="Enter your mobile number"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && fetchHistory()}
        />
        <button onClick={fetchHistory} disabled={loading}
          className="btn-primary flex items-center gap-2 px-4">
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
          Search
        </button>
      </div>

      {searched && orders.length === 0 && (
        <div className="text-center py-12">
          <div className="text-4xl mb-3">📦</div>
          <p className="text-gray-500 font-medium">No orders found for this number</p>
        </div>
      )}

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="card">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div>
                <p className="font-bold text-gray-900">{order.order_id}</p>
                <p className="text-xs text-gray-400">
                  {format(new Date(order.created_at), "dd MMM yyyy, hh:mm a")}
                </p>
              </div>
              <StatusBadge status={order.status} />
            </div>

            <div className="flex items-center justify-between">
              <p className="font-semibold text-gray-900">₹{order.total_amount.toFixed(2)}</p>
              <button onClick={() => toggle(order.id)}
                className="flex items-center gap-1 text-sm text-brand-600 hover:text-brand-700 font-medium">
                {expanded[order.id] ? <><ChevronUp size={14} /> Less</> : <><ChevronDown size={14} /> Details</>}
              </button>
            </div>

            {expanded[order.id] && (
              <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
                {order.items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <div>
                      <p className="font-medium text-gray-800">{item.medicine_name}</p>
                      <p className="text-xs text-gray-400">x{item.quantity} · ₹{item.unit_price}/unit</p>
                    </div>
                    <p className="font-semibold">₹{item.subtotal.toFixed(2)}</p>
                  </div>
                ))}
                <div className="pt-2 text-sm text-gray-500">
                  <p>📍 {order.address}, {order.city}, {order.state} – {order.pin_code}</p>
                  {order.order_notes && <p className="mt-1">📝 {order.order_notes}</p>}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
