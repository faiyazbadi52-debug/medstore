import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, Loader2 } from "lucide-react";
import { toast } from "react-hot-toast";
import api from "../../utils/api";
import OrderTracker from "../../components/user/OrderTracker";
import StatusBadge from "../../components/shared/StatusBadge";
import { format } from "date-fns";

export default function TrackPage() {
  const [params] = useSearchParams();
  const [orderId, setOrderId] = useState(params.get("id") || "");
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (params.get("id")) search(params.get("id"));
  }, []);

  async function search(id = orderId) {
    if (!id.trim()) { toast.error("Enter an Order ID"); return; }
    setLoading(true);
    setOrder(null);
    try {
      const { data } = await api.get(`/orders/track/${id.trim().toUpperCase()}`);
      setOrder(data);
    } catch {
      toast.error("Order not found. Please check your Order ID.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Track Your Order</h1>

      {/* Search */}
      <div className="flex gap-2 mb-8">
        <input
          className="input flex-1"
          placeholder="Enter Order ID (e.g. MED-20240629-A3X9)"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value.toUpperCase())}
          onKeyDown={(e) => e.key === "Enter" && search()}
        />
        <button onClick={() => search()} disabled={loading}
          className="btn-primary flex items-center gap-2 px-4">
          {loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
          Track
        </button>
      </div>

      {order && (
        <div className="space-y-5">
          {/* Status header */}
          <div className="card flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Order ID</p>
              <p className="font-bold text-lg text-gray-900">{order.order_id}</p>
              <p className="text-xs text-gray-400 mt-1">
                Placed on {format(new Date(order.created_at), "dd MMM yyyy, hh:mm a")}
              </p>
            </div>
            <StatusBadge status={order.status} />
          </div>

          {/* Tracker */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-4">Delivery Progress</h2>
            <OrderTracker status={order.status} />
          </div>

          {/* Order Items */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-3">Items Ordered</h2>
            <div className="space-y-2">
              {order.items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <p className="font-medium text-gray-800">{item.medicine_name}</p>
                    <p className="text-gray-400 text-xs">{item.medicine_brand} · x{item.quantity}</p>
                  </div>
                  <p className="font-semibold text-gray-900">₹{item.subtotal.toFixed(2)}</p>
                </div>
              ))}
            </div>
            <div className="flex justify-between font-bold text-gray-900 pt-3 mt-1 border-t border-gray-100">
              <span>Total</span>
              <span>₹{order.total_amount.toFixed(2)}</span>
            </div>
          </div>

          {/* Delivery info */}
          <div className="card">
            <h2 className="font-semibold text-gray-900 mb-3">Delivery Details</h2>
            <div className="text-sm space-y-1.5 text-gray-600">
              <p><span className="text-gray-400 w-20 inline-block">Name</span>{order.full_name}</p>
              <p><span className="text-gray-400 w-20 inline-block">Mobile</span>{order.mobile}</p>
              <p><span className="text-gray-400 w-20 inline-block">Address</span>{order.address}, {order.city}, {order.state} – {order.pin_code}</p>
              {order.landmark && <p><span className="text-gray-400 w-20 inline-block">Landmark</span>{order.landmark}</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
