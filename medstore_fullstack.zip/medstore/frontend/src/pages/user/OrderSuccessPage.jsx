import { useLocation, Link } from "react-router-dom";
import { CheckCircle, Copy, Package } from "lucide-react";
import { toast } from "react-hot-toast";

export default function OrderSuccessPage() {
  const { state } = useLocation();
  const order = state?.order;

  if (!order) return (
    <div className="max-w-md mx-auto px-4 py-20 text-center">
      <p className="text-gray-500">No order data found.</p>
      <Link to="/" className="btn-primary mt-4 inline-flex">Go Home</Link>
    </div>
  );

  const copy = () => {
    navigator.clipboard.writeText(order.order_id);
    toast.success("Order ID copied!");
  };

  return (
    <div className="max-w-lg mx-auto px-4 py-12 text-center">
      <div className="flex justify-center mb-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center">
          <CheckCircle size={44} className="text-green-500" />
        </div>
      </div>

      <h1 className="text-2xl font-bold text-gray-900 mb-2">Order Placed!</h1>
      <p className="text-gray-500 mb-6 text-sm">
        Thank you for your order. We'll prepare it right away.
      </p>

      {/* Order ID */}
      <div className="card bg-brand-50 border-brand-200 mb-6">
        <p className="text-sm text-brand-600 font-medium mb-1">Your Order ID</p>
        <div className="flex items-center justify-center gap-2">
          <span className="text-2xl font-bold text-brand-700 tracking-wider">{order.order_id}</span>
          <button onClick={copy} className="p-1.5 hover:bg-brand-100 rounded-lg transition-colors">
            <Copy size={16} className="text-brand-500" />
          </button>
        </div>
        <p className="text-xs text-brand-500 mt-2">Save this ID to track your order</p>
      </div>

      {/* Info */}
      <div className="card text-left mb-6 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">Total Amount</span>
          <span className="font-bold text-gray-900">₹{order.total_amount?.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Payment</span>
          <span className="font-medium">Cash on Delivery</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-500">Status</span>
          <span className="font-medium text-yellow-600">Pending</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Link to={`/track?id=${order.order_id}`}
          className="btn-primary flex-1 flex items-center justify-center gap-2">
          <Package size={16} /> Track Order
        </Link>
        <Link to="/" className="btn-secondary flex-1">Continue Shopping</Link>
      </div>
    </div>
  );
}
