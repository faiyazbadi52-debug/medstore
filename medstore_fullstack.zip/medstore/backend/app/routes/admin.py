"""Admin panel routes — dashboard, order management."""
import csv
import io
from flask import Blueprint, request, jsonify, Response
from flask_jwt_extended import jwt_required
from sqlalchemy import func, or_
from app import db
from app.models.order import Order, OrderItem

admin_bp = Blueprint("admin", __name__)

VALID_STATUSES = ["Pending", "Confirmed", "Preparing", "Out for Delivery", "Delivered", "Cancelled"]


def _require_admin(f):
    """Decorator: requires valid JWT."""
    from functools import wraps
    @wraps(f)
    @jwt_required()
    def decorated(*args, **kwargs):
        return f(*args, **kwargs)
    return decorated


# ── Dashboard ──────────────────────────────────────────────────────────────────

@admin_bp.route("/dashboard", methods=["GET"])
@_require_admin
def dashboard():
    totals = db.session.query(Order.status, func.count(Order.id)).group_by(Order.status).all()
    status_map = {s: c for s, c in totals}

    revenue = db.session.query(func.sum(Order.total_amount)).filter(
        Order.status == "Delivered"
    ).scalar() or 0

    return jsonify({
        "total_orders": sum(status_map.values()),
        "pending": status_map.get("Pending", 0),
        "confirmed": status_map.get("Confirmed", 0),
        "preparing": status_map.get("Preparing", 0),
        "out_for_delivery": status_map.get("Out for Delivery", 0),
        "delivered": status_map.get("Delivered", 0),
        "cancelled": status_map.get("Cancelled", 0),
        "total_revenue": float(revenue),
    }), 200


# ── Order List ─────────────────────────────────────────────────────────────────

@admin_bp.route("/orders", methods=["GET"])
@_require_admin
def get_orders():
    page = int(request.args.get("page", 1))
    per_page = min(int(request.args.get("per_page", 20)), 100)
    search = request.args.get("search", "").strip()
    status = request.args.get("status", "").strip()
    date_from = request.args.get("date_from", "").strip()
    date_to = request.args.get("date_to", "").strip()

    query = Order.query

    if search:
        like = f"%{search}%"
        query = query.filter(
            or_(
                Order.order_id.ilike(like),
                Order.full_name.ilike(like),
                Order.mobile.ilike(like),
            )
        )
    if status and status in VALID_STATUSES:
        query = query.filter(Order.status == status)
    if date_from:
        query = query.filter(Order.created_at >= date_from)
    if date_to:
        query = query.filter(Order.created_at <= date_to + " 23:59:59")

    paginated = query.order_by(Order.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return jsonify({
        "orders": [o.to_dict() for o in paginated.items],
        "total": paginated.total,
        "pages": paginated.pages,
        "page": page,
        "per_page": per_page,
    }), 200


# ── Single Order ───────────────────────────────────────────────────────────────

@admin_bp.route("/orders/<string:order_id>", methods=["GET"])
@_require_admin
def get_order(order_id):
    order = Order.query.filter_by(order_id=order_id.upper()).first_or_404()
    return jsonify(order.to_dict(include_items=True)), 200


# ── Update Status ──────────────────────────────────────────────────────────────

@admin_bp.route("/orders/<string:order_id>/status", methods=["PATCH"])
@_require_admin
def update_status(order_id):
    data = request.get_json(silent=True) or {}
    new_status = data.get("status", "").strip()
    if new_status not in VALID_STATUSES:
        return jsonify({"error": f"Invalid status. Must be one of: {', '.join(VALID_STATUSES)}"}), 422

    order = Order.query.filter_by(order_id=order_id.upper()).first_or_404()
    order.status = new_status
    db.session.commit()
    return jsonify({"message": f"Order status updated to '{new_status}'.", "status": new_status}), 200


# ── Delete Order ───────────────────────────────────────────────────────────────

@admin_bp.route("/orders/<string:order_id>", methods=["DELETE"])
@_require_admin
def delete_order(order_id):
    order = Order.query.filter_by(order_id=order_id.upper()).first_or_404()
    db.session.delete(order)
    db.session.commit()
    return jsonify({"message": "Order deleted successfully."}), 200


# ── Export CSV ─────────────────────────────────────────────────────────────────

@admin_bp.route("/orders/export/csv", methods=["GET"])
@_require_admin
def export_csv():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "Order ID", "Date", "Customer Name", "Mobile", "Email",
        "Address", "City", "State", "PIN", "Landmark",
        "Payment", "Total Amount", "Status", "Notes"
    ])
    for o in orders:
        writer.writerow([
            o.order_id,
            o.created_at.strftime("%Y-%m-%d %H:%M") if o.created_at else "",
            o.full_name, o.mobile, o.email or "",
            o.address, o.city, o.state, o.pin_code, o.landmark or "",
            o.payment_method, float(o.total_amount), o.status, o.order_notes or "",
        ])
    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=medstore_orders.csv"},
    )
