"""Customer order routes — place order, track order, view history."""
from flask import Blueprint, request, jsonify
from app import db, limiter
from app.models.order import Order, OrderItem
from app.models.medicine import Medicine
from app.utils.validators import validate_order_payload, sanitize

orders_bp = Blueprint("orders", __name__)


@orders_bp.route("/", methods=["POST"])
@limiter.limit("5 per minute")
def place_order():
    data = request.get_json(silent=True) or {}

    errors = validate_order_payload(data)
    if errors:
        return jsonify({"errors": errors}), 422

    # ── Compute totals & verify medicines ────────────────────────────────────
    items_data = data["items"]
    total = 0.0
    resolved_items = []

    for item in items_data:
        med = Medicine.query.filter_by(id=item["medicine_id"], is_active=True).first()
        if not med:
            return jsonify({"error": f"Medicine ID {item['medicine_id']} not found."}), 404
        qty = int(item["quantity"])
        subtotal = float(med.price) * qty
        total += subtotal
        resolved_items.append({
            "medicine": med,
            "qty": qty,
            "subtotal": subtotal,
        })

    # ── Create order ─────────────────────────────────────────────────────────
    order = Order(
        order_id=Order.generate_order_id(),
        full_name=sanitize(data["full_name"]),
        mobile=sanitize(data["mobile"]),
        email=sanitize(data.get("email", "") or ""),
        address=sanitize(data["address"]),
        city=sanitize(data["city"]),
        state=sanitize(data["state"]),
        pin_code=sanitize(data["pin_code"]),
        landmark=sanitize(data.get("landmark", "") or ""),
        payment_method="Cash on Delivery",
        order_notes=sanitize(data.get("order_notes", "") or ""),
        total_amount=round(total, 2),
        status="Pending",
    )
    db.session.add(order)
    db.session.flush()  # get order.id

    for ri in resolved_items:
        med = ri["medicine"]
        item = OrderItem(
            order_id_fk=order.id,
            medicine_id=med.id,
            medicine_name=med.name,
            medicine_brand=med.brand,
            unit_price=float(med.price),
            quantity=ri["qty"],
            subtotal=ri["subtotal"],
        )
        db.session.add(item)

    db.session.commit()

    return jsonify({
        "message": "Order placed successfully!",
        "order_id": order.order_id,
        "total_amount": float(order.total_amount),
        "status": order.status,
    }), 201


@orders_bp.route("/track/<string:order_id>", methods=["GET"])
def track_order(order_id):
    order = Order.query.filter_by(order_id=order_id.upper()).first()
    if not order:
        return jsonify({"error": "Order not found. Check the Order ID and try again."}), 404
    return jsonify(order.to_dict(include_items=True)), 200


@orders_bp.route("/history", methods=["GET"])
@limiter.limit("20 per minute")
def order_history():
    mobile = request.args.get("mobile", "").strip()
    if not mobile:
        return jsonify({"error": "Mobile number is required to view order history."}), 400

    orders = (
        Order.query.filter_by(mobile=mobile)
        .order_by(Order.created_at.desc())
        .limit(50)
        .all()
    )
    return jsonify({"orders": [o.to_dict(include_items=True) for o in orders]}), 200
