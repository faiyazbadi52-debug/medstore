"""Medicine catalogue routes."""
from flask import Blueprint, jsonify, request
from app.models.medicine import Medicine

medicines_bp = Blueprint("medicines", __name__)


@medicines_bp.route("/", methods=["GET"])
def get_medicines():
    category = request.args.get("category", "").strip()
    search = request.args.get("search", "").strip()

    query = Medicine.query.filter_by(is_active=True)

    if category:
        query = query.filter(Medicine.category == category)
    if search:
        like = f"%{search}%"
        query = query.filter(
            Medicine.name.ilike(like) | Medicine.brand.ilike(like)
        )

    medicines = query.order_by(Medicine.category, Medicine.name).all()
    categories = sorted({m.category for m in Medicine.query.filter_by(is_active=True).all()})

    return jsonify({
        "medicines": [m.to_dict() for m in medicines],
        "categories": categories,
    }), 200


@medicines_bp.route("/<int:med_id>", methods=["GET"])
def get_medicine(med_id):
    med = Medicine.query.filter_by(id=med_id, is_active=True).first_or_404()
    return jsonify(med.to_dict()), 200
